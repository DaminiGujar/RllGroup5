package com.entity;

public class PrimaryAccount {


    private Long id;

   
    private int accountNumber;


    
    private int accountBalance;
    
    public PrimaryAccount() {}

    public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public int getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}

	public int getAccountBalance() {
		return accountBalance;
	}

	public void setAccountBalance(int accountBalance) {
		this.accountBalance = accountBalance;
	}



	@Override
	public String toString() {
		return "PrimaryAccount [id=" + id + ","
				+ " accountNumber=" + accountNumber + ","
				+ " accountBalance=" + accountBalance + "]";
	}

//	@OneToMany(mappedBy = "PrimaryAccount", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
//	@JsonIgnore
//    private List<PrimaryTransaction> primaryTransactionList;
    
    
 
    





}
