package com.fallback;

import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Component;

import com.entity.PrimaryAccount;
import com.proxy.BankServiceProxy;
@Component
public class BankServiceFallback implements BankServiceProxy {

	@Override
	public List<PrimaryAccount> getAccounts() {
		// TODO Auto-generated method stub
		return Arrays.asList(new PrimaryAccount());
	}

	@Override
	public PrimaryAccount save(PrimaryAccount primaryAccount) {
		// TODO Auto-generated method stub
		return null;
	}

//	@Override
//	public PrimaryAccount save(PrimaryAccount primaryAccount) {
//		
//		// TODO Auto-generated method stub
//		return ;
//	}

}
