package com.proxy;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.entity.PrimaryAccount;
import com.fallback.BankServiceFallback;


@FeignClient(name="book-service" ,fallback = BankServiceFallback.class)

public interface BankServiceProxy {
	
	
	
	 @GetMapping("/all")
	    public List<PrimaryAccount> getAccounts();
	 
	 @PostMapping(value="/saveprimaryaccount", produces = {MediaType.APPLICATION_JSON_VALUE},
				consumes = {MediaType.APPLICATION_JSON_VALUE})
		@ResponseStatus(code = HttpStatus.CREATED)
	 public PrimaryAccount save( PrimaryAccount primaryAccount);
}
