package com.services;

import com.entity.UserLogin;
import org.springframework.stereotype.Component;


@Component

public interface LoginValidationService {

    public boolean isAdminUserNameValid(String userName);
    public boolean isAdminPasswordValid(String password);

    public UserLogin isValidUser(String userId);
    public boolean isUserPasswordValid(UserLogin user, String password);
	

}
