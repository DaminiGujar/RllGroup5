package com.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.entity.LoginDashboard;
import com.repository.LoginDashboardRepository;

@Service
public class LoginDashboardService {
	
	@Autowired
	LoginDashboardRepository loginDashboardRepository;
	
	public String signIn(LoginDashboard loginDashboard) {
		boolean res = loginDashboardRepository.existsById(loginDashboard.getEmailid());
		if(loginDashboard.getTypeOfUser().equals("admin")) {
			if(loginDashboardRepository.checkLoginDetails(loginDashboard.getEmailid(), loginDashboard.getPassword(),loginDashboard.getTypeOfUser())!=null) {
				return "admin login successfully";
			}else {
				return "failure";
			}
		}else {
			if(loginDashboardRepository.checkLoginDetails(loginDashboard.getEmailid(), loginDashboard.getPassword(),loginDashboard.getTypeOfUser())!=null) {
				return "user login successfully";
			}else {
				return "failure";
			}
		}
	}
}


