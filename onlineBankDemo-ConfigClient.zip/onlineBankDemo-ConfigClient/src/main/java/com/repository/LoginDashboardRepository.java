package com.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.entity.LoginDashboard;







@Repository
public interface LoginDashboardRepository extends JpaRepository<LoginDashboard, String>{

	@Query("select ll from LoginDashboard ll where ll.emailid = :emailid and ll.password = :password and typeofuser=:typeofuser")
public LoginDashboard checkLoginDetails(@Param("emailid") String emailId, @Param("password") String pass,@Param("typeofuser") String typeOfUser);
	
}
