package com.repository;

import com.entity.UserLogin;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;


public interface UserRepository extends JpaRepository<UserLogin, Long> {
    List<UserLogin> findByFirstName(String firstName);
    UserLogin findByUserId(String userId);
    UserLogin findByEmail(String email);
    UserLogin save(UserLogin user);
}
