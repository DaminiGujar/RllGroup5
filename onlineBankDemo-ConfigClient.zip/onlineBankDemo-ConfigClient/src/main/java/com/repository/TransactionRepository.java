package com.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.entity.PrimaryAccount;
import com.entity.Transactions;
@Repository
public interface TransactionRepository extends JpaRepository<Transactions, Long>{
	
	
	public List<Transactions> findAll();
    public Transactions save(Transactions transactions);
	
//	Transactions save(Transactions transactions);
//	Transactions update(Transactions transactions);
//	void delete(Long id);
//	
//	List<Transactions> getAllTransactions();
//	
//	Transactions getTransactionsById(Long id);

}
