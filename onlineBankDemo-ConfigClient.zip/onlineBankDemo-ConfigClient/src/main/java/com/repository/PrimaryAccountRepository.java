package com.repository;

import com.entity.PrimaryAccount;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PrimaryAccountRepository extends JpaRepository<PrimaryAccount, Long> {

   // public PrimaryAccount findPrimarAccountById(Long id);
    public List<PrimaryAccount> findAll();
    public PrimaryAccount save(PrimaryAccount primaryAccount);
    
	//PrimaryAccount findByAccountNumber(int accountNumber);
 //   public int  delete(int id);
 //   public Policy updatePolicy(Policy policy);

}
