package com.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "request_table")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})

public class Request {
	
	
	 @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long id;
	    private Date date;
	   // private String location;
	    
	    private String description;
	    
	    private boolean confirmed;
	    public Request() {}

		public Long getId() {
			return id;
		}

		public void setId(Long id) {
			this.id = id;
		}

		public Date getDate() {
			return date;
		}

		public void setDate(Date date) {
			this.date = date;
		}

		public String getDescription() {
			return description;
		}

		public void setDescription(String description) {
			this.description = description;
		}

		public boolean isConfirmed() {
			return confirmed;
		}

		public void setConfirmed(boolean confirmed) {
			this.confirmed = confirmed;
		}

		public Request(Long id, Date date, String description, boolean confirmed) {
			super();
			this.id = id;
			this.date = date;
			this.description = description;
			this.confirmed = confirmed;
		}

		@Override
		public String toString() {
			return "Request [id=" + id + ", date=" + date + ", description=" + description + ", confirmed=" + confirmed
					+ "]";
		}
	    

}
