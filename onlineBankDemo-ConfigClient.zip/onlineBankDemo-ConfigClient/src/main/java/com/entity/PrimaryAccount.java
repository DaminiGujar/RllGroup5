package com.entity;


//import com.example.demo.entity.PrimaryTransaction;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import javax.persistence.*;


@Entity
@Table(name = "primary_Account")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class PrimaryAccount {


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "account_number")
    private int accountNumber;

//    @Column(name = "detailed_name")
//    private String detailedName;
    
    @Column(name = "account_balance")
    private int accountBalance;
    
    public PrimaryAccount() {}

    public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public int getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}

	public int getAccountBalance() {
		return accountBalance;
	}

	public void setAccountBalance(int accountBalance) {
		this.accountBalance = accountBalance;
	}



	@Override
	public String toString() {
		return "PrimaryAccount [id=" + id + ","
				+ " accountNumber=" + accountNumber + ","
				+ " accountBalance=" + accountBalance + "]";
	}

//	@OneToMany(mappedBy = "PrimaryAccount", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
//	@JsonIgnore
//    private List<PrimaryTransaction> primaryTransactionList;
    
    
 
    





}
