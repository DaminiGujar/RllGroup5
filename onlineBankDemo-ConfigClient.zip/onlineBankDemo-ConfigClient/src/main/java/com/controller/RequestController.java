package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.entity.Request;
import com.entity.Transactions;
import com.repository.RequestRepository;
import com.repository.TransactionRepository;

@RestController
@RequestMapping("/request")
public class RequestController {
	
	
	@Autowired
	private RequestRepository requestRepository;
	
	
	 /**
     * http://localhost:8090/request/all
     * @return all requests 
     */
	@GetMapping("/all")
	public List<Request> findAll(){
		return requestRepository.findAll();
	}
	
	
	 /**
     * http://localhost:8090/request/saverequest
     * @return saved  requests 
     */
	
	@PostMapping(value="/saverequest", produces = {MediaType.APPLICATION_JSON_VALUE},
			consumes = {MediaType.APPLICATION_JSON_VALUE})
	@ResponseStatus(code = HttpStatus.CREATED)
	
	public Request save(@RequestBody Request Request) {
		return requestRepository.save(Request);
	}

	
	
	
	
	
	
}
