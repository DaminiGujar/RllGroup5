package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.entity.SavingAccount;
import com.repository.SavingAccountRepository;

@RestController
@RequestMapping("/savingaccounts")
public class SavingAccountController {
	

	@Autowired
	private SavingAccountRepository savingAccountRepository;
	
	/**
     * http://localhost:8090/savingaccounts/all
     * @return all savingaccounts 
     */
	 @GetMapping("/all")
	    public List<SavingAccount> findAll(){
	    	return savingAccountRepository.findAll();
	    }
	 
	 /**
	     * http://localhost:8090/savingaccounts/savesavingaccount
	     * @return save savingaccounts 
	     */
	    @PostMapping(value="/savesavingaccount", produces = {MediaType.APPLICATION_JSON_VALUE},
				consumes = {MediaType.APPLICATION_JSON_VALUE})
		@ResponseStatus(code = HttpStatus.CREATED)
	    public SavingAccount save(@RequestBody SavingAccount savingAccount) {
	    	return savingAccountRepository.save(savingAccount);
	    }
	    
	    /**
	     * http://localhost:8090/savingaccounts/getsavingaccbyid/1
	     * @return  savingaccounts  by Id
	     */
	    @GetMapping(value="/getsavingaccbyid/{id}", produces = {MediaType.APPLICATION_JSON_VALUE}) 
	    public SavingAccount getSavingAccountById(@PathVariable Long id) {
	    	return savingAccountRepository.getSavingAccountById(id);
	    	
	    	
	    	
	    	
	    	
	    }

}
