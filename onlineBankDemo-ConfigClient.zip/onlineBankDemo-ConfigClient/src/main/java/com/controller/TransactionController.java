package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.entity.Transactions;
import com.repository.TransactionRepository;

@RestController
@RequestMapping("/transactions")
public class TransactionController {
	@Autowired
	private TransactionRepository transactionRepository;
	
	 /**
     * http://localhost:8090/transactions/all
     * @return  all transactions
     */
	@GetMapping("/all")
	public List<Transactions> findAll(){
		return transactionRepository.findAll();
	}
	

	 /**
    * http://localhost:8090/transactions/savetransaction
    * @return  save transactions
    */
	@PostMapping(value="/savetransaction", produces = {MediaType.APPLICATION_JSON_VALUE},
			consumes = {MediaType.APPLICATION_JSON_VALUE})
	@ResponseStatus(code = HttpStatus.CREATED)
	
	public Transactions save(@RequestBody Transactions transactions) {
		return transactionRepository.save(transactions);
		
	}
	
	
//	 @PostMapping(value="/savetransaction", produces = {MediaType.APPLICATION_JSON_VALUE},
//				consumes = {MediaType.APPLICATION_JSON_VALUE})
//		@ResponseStatus(code = HttpStatus.CREATED)
//	public Transactions save(@RequestBody Transactions transactions) {
//		 return transactionRepository.save(transactions);
//		
//	}
//
//	 @PutMapping(value="/updatetransaction", produces = {MediaType.APPLICATION_JSON_VALUE}) 
//
//		@ResponseStatus(code=HttpStatus.OK) 
//	 public Transactions update(@RequestBody Transactions transactions) {
//		 return transactionRepository.update(transactions);
//	 }
//	 @DeleteMapping(value="/deletetransaction/{id}") 
//
//		@ResponseStatus(code=HttpStatus.NO_CONTENT)
//	 public void delete(Long id) {
//		 transactionRepository.delete(id);
//	 }
//	 @GetMapping(value = "/transaction", produces = {MediaType.APPLICATION_JSON_VALUE})
//	 public List<Transactions> getAllTransactions(){
//		 return transactionRepository.getAllTransactions();
//	 }
}
