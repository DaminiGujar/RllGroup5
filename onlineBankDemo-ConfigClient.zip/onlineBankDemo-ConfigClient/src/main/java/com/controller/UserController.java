package com.controller;

import com.config.LoginValidationConfig;
import com.entity.UserLogin;

import com.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;


import java.util.List;



@RestController
@RequestMapping("/users")
public class UserController {
    @Autowired
    UserRepository userRepository;
   
    @Autowired
    LoginValidationConfig tripleCoverConfig;

    private Logger logger = LoggerFactory.getLogger(this.getClass());


    /**
     * http://localhost:8090/user/1
     * @param id - of the user
     * @return One User object.
     */
    @RequestMapping("/user/{id}")
    public UserLogin get(@PathVariable(value = "id") Long id) {
        logger.info("Id passed "+id);
        UserLogin user = userRepository.getOne(id);
        logger.info("User {}",user);
        return user;
    }

    /**
     * Example
     * http://localhost:8090/userid/1
     * @param userId 
     */

    @RequestMapping("/userid/{userId}")
    public UserLogin getOneUserByUserId(@PathVariable(value = "userId")String userId) {
        logger.info("User Id passed "+userId);
        if(tripleCoverConfig.getAdminUserName().equals(userId)) {
            UserLogin user = new UserLogin();
            user.setUserId(userId);
            user.setPassword(userId);
            user.setFirstName(userId);
            user.setLastName(userId);
            return user;
        }
        UserLogin user = userRepository.findByUserId(userId);
        logger.info("User {}",user);
        return user;

    }

    /**
     * Postman URL http://localhost:8090/users/all
     * @return all users...
     */

    @GetMapping("/all")
    public List<UserLogin> list(){
        return userRepository.findAll();
    }
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public UserLogin create(@RequestBody @Validated UserLogin user) {
        return userRepository.save(user);
    }
    /**
     * POST URI http://localhost:8090/users/
     * Create new user
     * @param user
     *
     * To update pass
     *  {
     *         "id": 12,
     *         "userId": "test12",
     *         "firstName": "12 Tester first name",
     *         "lastName": "12 Tester Last name",
     *         "birthDate": "1988-01-12",
     *         "address": "tester street 12, tester city, tester state, 10001",
     *         "contactNumber": "+1 122-333-4444",
     *         "email": "tester12@testers.com",
     *         "password": "122-433p2d-"
     *     }
     *
     *     To create pass without ID
     */
   

    
   
    
    

}
