package com.controller;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.entity.LoginDashboard;
import com.services.LoginDashboardService;




@RestController
@RequestMapping("login")
 
public class LoginDashboardController {

	
	// http://localhost:8080/login/signIn
	
	@Autowired
	LoginDashboardService loginDashboardService;
	
	@PostMapping(value = "signIn")
	public String signIn(@RequestBody LoginDashboard ll) {
			System.out.println(ll);
		return loginDashboardService.signIn(ll);
	}
}
