package com.controller;

import com.entity.PrimaryAccount;
import com.repository.PrimaryAccountRepository;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;


import java.util.ArrayList;
import java.util.List;


@RestController
@RequestMapping("/primaryaccounts")
public class PrimaryAccountController {
    @Autowired
    PrimaryAccountRepository primaryAccountRepository;
    
    private Logger logger = LoggerFactory.getLogger(this.getClass());
    
    /**
     * http://localhost:8090/primaryaccounts/all
     * @return all primaryaccounts 
     */
    @GetMapping("/all")
    public List<PrimaryAccount> findAll(){
    	return primaryAccountRepository.findAll();
    }
    
    
    /**
     * http://localhost:8090/primaryaccounts/saveprimaryaccount
     *save primary accounts
     */
    @PostMapping(value="/saveprimaryaccount", produces = {MediaType.APPLICATION_JSON_VALUE},
			consumes = {MediaType.APPLICATION_JSON_VALUE})
	@ResponseStatus(code = HttpStatus.CREATED)
    public PrimaryAccount save(@RequestBody PrimaryAccount primaryAccount) {
    	return primaryAccountRepository.save(primaryAccount);
    }
    
    



   


}
